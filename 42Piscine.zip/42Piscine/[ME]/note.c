char    = {"a", "b", "c"} 
int     numberName = 1
float   hexName = 3.1
void    == NULL

string stringName[] = {"degjhior", "zzz", "rg"}; 

&& == and
|| == or
!= == ~=
